<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currículum Vitae</title>


    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        color: #333;
    }

    .info-table {
        width: 100%;
        border-spacing: 20px;
        table-layout: fixed;
    }

    .photo-cell {
        width: 30%;
        vertical-align: middle;
        text-align: center;
    }

    .photo {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        object-fit: cover;
    }

    .personal-info-cell {
        vertical-align: middle;
        /* Centra verticalmente los datos */
        color: #333;
    }

    .personal-info-cell h1 {
        font-size: 24px;
        margin: 0;
        color: #0056b3;
    }

    .personal-info-cell p {
        margin: 5px 0;
        font-size: 14px;
    }

    .container {
        width: 100%;
        padding: 0px 10px 10px 10px
    }

    .header {
        margin-bottom: 20px;
        border-bottom: 2px;
        padding-bottom: 10px;
    }

    .section {
        margin-bottom: 20px;
    }

    .section h2 {
        font-size: 20px;
        border-bottom: 2px solid #0056b3;
        margin-bottom: 10px;
        color: #0056b3;
    }

    .list-item {
        margin: 5px 0;
        font-size: 14px;
    }

    .academic,
    .experience,
    .skills {
        padding-left: 15px;
    }

    .name-title {
        text-align: center;
        /* Centra el nombre y título */
        margin-bottom: 20px;
    }

    .aligned-table {
        width: 100%;
        /* La tabla ocupa todo el ancho */
        border-spacing: 0;
        /* Sin espacio entre celdas */
        table-layout: fixed;
        /* Ancho fijo para distribuir columnas equitativamente */
    }

    .left-cell {
        text-align: left;
        /* Alinea la primera columna a la izquierda */
        padding: 5px;
        width: 50%;
        /* Ocupa el 50% del ancho */
    }

    .right-cell {
        text-align: right;
        /* Alinea la segunda columna a la derecha */
        padding: 5px;
        width: 50%;
        /* Ocupa el 50% del ancho */
    }
    </style>
</head>

<body>
    <?php if(isset($curriculum)): ?>
    <div class="container">
        <!-- Header con foto y datos personales -->
        <div class="header">
            <table class="info-table">
                <tr>
                    <!-- Primera columna: Foto -->
                    <td class="photo-cell">
                        <?php if($photo): ?>
                        <img src='<?php echo e("storage/$photo->url"); ?>' alt="Foto" class="photo">
                        <?php endif; ?>
                    </td>
                    <!-- Segunda columna: Datos personales -->
                    <td class="personal-info-cell">
                        <div class="name-title">
                            <h1><?php echo e($curriculum->first_name); ?> <?php echo e($curriculum->last_name); ?></h1>
                            <h2><?php echo e($curriculum->professional_title); ?></h2>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <table class="aligned-table">
            <tr>
                <td class="left-cell"><?php echo e($curriculum->email); ?></td>
                <td class="right-cell"><?php echo e($curriculum->locality); ?>, <?php echo e($curriculum->state); ?>, <?php echo e($curriculum->country); ?>

                </td>

            </tr>
            <tr>
                <td class="left-cell"><?php echo e($curriculum->phone_num ?? 'No registrado'); ?></td>
                <td class="right-cell"><?php echo e($curriculum->linkedin); ?></td>
            </tr>
        </table>


        <!-- Resumen profesional -->
        <div class="section">
            <h2>Resumen Profesional</h2>
            <p><?php echo e($curriculum->professional_summary); ?></p>
        </div>

        <!-- Educación -->
        <div class="section">
            <h2>Educación</h2>
            <ul class="academic">
                <?php $__currentLoopData = $academic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-item">
                    <strong><?php echo e($aca['postgraduate_name']); ?></strong> - <?php echo e($aca['institute_name']); ?> <br>
                    <small><?php echo e($aca['postgraduate_start_date']); ?> - <?php echo e($aca['postgraduate_end_date']); ?></small>
                    <p>- <?php echo e($aca['highlight']); ?></p>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Experiencia laboral -->
        <div class="section">
            <h2>Experiencia Laboral</h2>
            <ul class="experience">
                <?php $__currentLoopData = $workExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-item">
                    <strong><?php echo e($job['job_position']); ?></strong> - <?php echo e($job['business_name']); ?> <br>
                    <small><?php echo e($job['start_date']); ?> - <?php echo e($job['end_date']); ?></small>
                    <ul>
                        <li> <b>Funciones:</b> <?php echo e($job['responsibility']); ?></li>
                        <li> <b>Logros:</b> <?php echo e($job['achievement']); ?></li>
                    </ul>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Educación continua -->
        <div class="section">
            <h2>Educación continua</h2>
            <ul class="experience">
                <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-item">
                    <strong><?php echo e($edu['course_name']); ?></strong> - <?php echo e($edu['course_institute']); ?> <br>
                    <small><?php echo e($edu['course_start_date']); ?> - <?php echo e($edu['course_end_date']); ?></small>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Habilidades y conocimientos -->
        <div class="section">
            <h2>Habilidades y Conocimientos</h2>
            <ul class="skills">
                <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-item">
                    <strong>
                        <?php echo e($skill['type'] === 'SOFTWARE' ? 'Software' :
                ($skill['type'] === 'LANGUAGE' ? 'Lenguaje' :
                ($skill['type'] === 'OTHER' ? $skill['other_knowledge'] : ""))); ?>

                    </strong> <br>
                    <small><?php echo e($skill['description_knowledge']); ?> -



                        <?php echo e($skill['level'] === 'BEGINNER' ? 'Principiante' :
                ($skill['level'] === 'INTERMEDIATE' ? 'Intermedio' :
                ($skill['level'] === 'ADVANCED' ? 'Avanzado' : ""))); ?>


                    </small>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Users\david\Escritorio\laravel\impulsou-api\resources\views/pdf/template.blade.php ENDPATH**/ ?>